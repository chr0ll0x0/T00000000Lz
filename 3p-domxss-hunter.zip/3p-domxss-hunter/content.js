(() => {
  function isThirdParty(scriptUrl, pageOrigin) {
    try {
      const scriptHost = new URL(scriptUrl).hostname;
      const pageHost = new URL(pageOrigin).hostname;
      if (scriptHost === pageHost) return false;
      const pageParts = pageHost.split(".");
      const scriptParts = scriptHost.split(".");
      const pageRoot = pageParts.slice(-2).join(".");
      const scriptRoot = scriptParts.slice(-2).join(".");
      if (pageRoot === scriptRoot) return false;
      return true;
    } catch {
      return false;
    }
  }

  function collectThirdPartyScripts() {
    const scripts = Array.from(document.querySelectorAll("script[src]"));
    const origin = window.location.origin;
    const thirdParty = [];
    const firstParty = [];

    for (const s of scripts) {
      const url = s.src;
      if (!url) continue;
      if (isThirdParty(url, origin)) {
        thirdParty.push(url);
      } else {
        firstParty.push(url);
      }
    }

    return { thirdParty, firstParty, total: scripts.length };
  }

  function collectInlineScripts() {
    return Array.from(document.querySelectorAll("script:not([src])"))
      .map(s => s.textContent)
      .filter(t => t && t.trim().length > 10);
  }

  function collectPostMessageListeners() {
    const results = [];
    try {
      if (typeof getEventListeners === "function") {
        const listeners = getEventListeners(window);
        if (listeners.message) {
          results.push({ count: listeners.message.length, source: "getEventListeners" });
        }
      }
    } catch {}
    return results;
  }

  function getSecurityHeaders() {
    const meta = {};
    document.querySelectorAll("meta[http-equiv]").forEach(m => {
      meta[m.getAttribute("http-equiv")] = m.getAttribute("content");
    });
    return {
      csp: meta["Content-Security-Policy"] || meta["content-security-policy"] || null,
      xfo: meta["X-Frame-Options"] || meta["x-frame-options"] || null,
    };
  }

  function detectTechStack() {
    const stack = [];
    if (window.jQuery || window.$) stack.push("jQuery " + (window.jQuery ? window.jQuery.fn.jquery : ""));
    if (window.angular) stack.push("AngularJS");
    if (window.ng) stack.push("Angular");
    if (window.__REACT_DEVTOOLS_GLOBAL_HOOK__ || document.querySelector("[data-reactroot]")) stack.push("React");
    if (window.__VUE__) stack.push("Vue");
    if (window.__SVELTE__) stack.push("Svelte");
    if (window.__NEXT_DATA__) stack.push("Next.js");
    if (window.__NUXT__) stack.push("Nuxt.js");
    if (window.Shopify) stack.push("Shopify");
    if (window.DOMPurify) stack.push("DOMPurify");
    if (document.querySelector("[data-hj-suppress]")) stack.push("Hotjar");
    if (window.ga || window.gtag) stack.push("Google Analytics");
    if (window._satellite) stack.push("Adobe Launch");
    if (window.Tealium || window.utag) stack.push("Tealium");
    if (window.drift) stack.push("Drift");
    if (window.Intercom) stack.push("Intercom");
    if (document.querySelector("script[src*='statcounter']")) stack.push("StatCounter");
    return stack;
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === "enumerate") {
      const scripts = collectThirdPartyScripts();
      const headers = getSecurityHeaders();
      const stack = detectTechStack();
      const inline = collectInlineScripts();
      const pmListeners = collectPostMessageListeners();

      sendResponse({
        url: window.location.href,
        origin: window.location.origin,
        scripts,
        headers,
        stack,
        inlineCount: inline.length,
        pmListeners,
      });
    }

    if (msg.action === "getInlineScripts") {
      sendResponse({ scripts: collectInlineScripts() });
    }

    if (msg.action === "getPageOrigin") {
      sendResponse({ origin: window.location.origin, url: window.location.href });
    }

    return true;
  });
})();
