const Scanner = (() => {

  // ── Ad-tech / analytics hosts — deprioritize findings from these ──
  const AD_TECH_HOSTS = [
    "doubleclick.net", "googlesyndication.com", "googletagmanager.com",
    "google-analytics.com", "googleadservices.com", "gstatic.com",
    "amazon-adsystem.com", "pubmatic.com", "facebook.net", "fbcdn.net",
    "emetriq.de", "twiago.com", "geoedge.be", "adnami.io", "id5-sync.com",
    "greenvideo.io", "criteo.com", "criteo.net", "outbrain.com", "taboola.com",
    "rubiconproject.com", "openx.net", "casalemedia.com", "indexexchange.com",
    "moatads.com", "doubleverify.com", "adsafeprotected.com", "iasds01.com",
    "adobedtm.com", "demdex.net", "omtrdc.net",
    "hotjar.com", "mouseflow.com", "clarity.ms",
    "cdn.cookielaw.org", "cookiebot.com",
    "newrelic.com", "nr-data.net", "sentry.io",
  ];

  function isAdTech(hostname) {
    const h = hostname.toLowerCase();
    return AD_TECH_HOSTS.some(ad => h === ad || h.endsWith("." + ad));
  }

  // ── Dangerous sinks ──
  const SINKS = [
    { id: "innerHTML",           re: /\.innerHTML\s*[=+]/, severity: "high" },
    { id: "outerHTML",           re: /\.outerHTML\s*[=+]/, severity: "high" },
    { id: "document.write",      re: /document\.write(ln)?\s*\(/, severity: "high" },
    { id: "eval",                re: /[^.]eval\s*\(/, severity: "critical" },
    { id: "Function()",          re: /new\s+Function\s*\(/, severity: "critical" },
    { id: "setTimeout-string",   re: /setTimeout\s*\(\s*["'`]/, severity: "high" },
    { id: "setInterval-string",  re: /setInterval\s*\(\s*["'`]/, severity: "high" },
    { id: "insertAdjacentHTML",  re: /insertAdjacentHTML\s*\(/, severity: "high" },
    { id: "srcdoc",              re: /\.srcdoc\s*[=+]/, severity: "high" },
    { id: "script.src=",         re: /\.src\s*=\s*[^=]/, severity: "high" },
    { id: "location.assign",     re: /location\.(assign|replace)\s*\(/, severity: "medium" },
    { id: "location.href=",      re: /location\.href\s*=/, severity: "medium" },
    { id: "window.open",         re: /window\.open\s*\(/, severity: "medium" },
    { id: "jQuery.html()",       re: /\.html\s*\([^)]+\)/, severity: "high" },
    { id: "jQuery.append()",     re: /\.append\s*\([^)]*[<'"`+]/, severity: "medium" },
    { id: "createElement-script", re: /createElement\s*\(\s*['"`]script/, severity: "high" },
    { id: "dangerouslySetInnerHTML", re: /dangerouslySetInnerHTML/, severity: "high" },
  ];

  // ── Attacker-controllable sources ──
  const SOURCES = [
    { id: "location.search",     re: /location\.search/ },
    { id: "location.hash",       re: /location\.hash/ },
    { id: "location.href",       re: /location\.href(?!\s*=)/ },
    { id: "location.pathname",   re: /location\.pathname/ },
    { id: "document.URL",        re: /document\.URL/ },
    { id: "document.referrer",   re: /document\.referrer/ },
    { id: "document.cookie",     re: /document\.cookie/ },
    { id: "window.name",         re: /window\.name/ },
    { id: "URLSearchParams",     re: /new\s+URLSearchParams/ },
    { id: "getQueryParam",       re: /get(Query)?Param(eter)?s?\s*\(/ },
    { id: "postMessage-data",    re: /\.data[\s.[]/ },
    { id: "localStorage",        re: /localStorage\.(get|set)Item/ },
    { id: "sessionStorage",      re: /sessionStorage\.(get|set)Item/ },
  ];

  // ── Source→Sink proximity patterns ──
  // Tightened: 200-char window (was 300-500). Catches real flows, skips same-file coincidence.
  const FLOW_PATTERNS = [
    { name: "location.hash→innerHTML",     re: /location\.hash[\s\S]{0,200}\.innerHTML\s*[=+]/g },
    { name: "location.hash→eval",          re: /location\.hash[\s\S]{0,200}eval\s*\(/g },
    { name: "location.hash→document.write", re: /location\.hash[\s\S]{0,200}document\.write/g },
    { name: "location.search→innerHTML",   re: /location\.search[\s\S]{0,200}\.innerHTML\s*[=+]/g },
    { name: "location.search→eval",        re: /location\.search[\s\S]{0,200}eval\s*\(/g },
    { name: "location.search→script.src",  re: /location\.search[\s\S]{0,200}\.src\s*=/g },
    { name: "location.href→innerHTML",     re: /location\.href[\s\S]{0,200}\.innerHTML\s*[=+]/g },
    { name: "document.referrer→innerHTML", re: /document\.referrer[\s\S]{0,200}\.innerHTML\s*[=+]/g },
    { name: "document.referrer→eval",      re: /document\.referrer[\s\S]{0,200}eval\s*\(/g },
    { name: "window.name→innerHTML",       re: /window\.name[\s\S]{0,200}\.innerHTML\s*[=+]/g },
    { name: "window.name→eval",            re: /window\.name[\s\S]{0,200}eval\s*\(/g },
    { name: "postMessage→innerHTML",       re: /\.data[\s\S]{0,150}\.innerHTML\s*[=+]/g },
    { name: "postMessage→eval",            re: /event\.data[\s\S]{0,150}eval\s*\(/g },
    { name: "postMessage→location",        re: /\.data[\s\S]{0,150}location\.(href|assign|replace)/g },
    { name: "URLSearchParams→innerHTML",   re: /URLSearchParams[\s\S]{0,200}\.innerHTML\s*[=+]/g },
    { name: "URLSearchParams→script.src",  re: /URLSearchParams[\s\S]{0,200}\.src\s*=/g },
    { name: "URLSearchParams→eval",        re: /URLSearchParams[\s\S]{0,200}eval\s*\(/g },
    { name: "cookie→innerHTML",            re: /document\.cookie[\s\S]{0,200}\.innerHTML\s*[=+]/g },
    { name: "hash→jQuery.html()",          re: /location\.hash[\s\S]{0,200}\.html\s*\(/g },
    { name: "search→jQuery.html()",        re: /location\.search[\s\S]{0,200}\.html\s*\(/g },
    { name: "location.href→script.src",    re: /location\.href[\s\S]{0,200}\.src\s*=/g },
    { name: "location.href→createElement-script", re: /location\.href[\s\S]{0,200}createElement\s*\(\s*['"`]script/g },
    { name: "location.href→S3-bucket",     re: /location\.href[\s\S]{0,300}s3[\w.-]*amazonaws/gi },
    { name: "location.href→split→concat",  re: /location\.href[\s\S]{0,150}split\s*\([\s\S]{0,100}\+/g },
    { name: "location.search→createElement-script", re: /location\.search[\s\S]{0,200}createElement\s*\(\s*['"`]script/g },
    { name: "location.hash→script.src",    re: /location\.hash[\s\S]{0,200}\.src\s*=/g },
  ];

  // ── Widget endpoint override params (proven patterns) ──
  const WIDGET_OVERRIDE_PARAMS = [
    /[\-_](server|endpoint|api|host|base[_-]?url|cdn|origin|domain|gateway|proxy|backend|service)/i,
    /widget[_-]?(server|url|endpoint|host|api)/i,
    /(api|server|host|endpoint|base|cdn|resource)[_-]?(url|uri|base|path|host|origin)/i,
    /(?:data|config|settings)[_-]?(url|endpoint|server|host)/i,
    /SSO[_-]?Url/i,
    /redirect[_-]?(uri|url|to|target)/i,
    /return[_-]?(url|to|uri)/i,
    /callback[_-]?(url|uri)/i,
    /next[_-]?url/i,
    /goto/i,
    /target[_-]?url/i,
  ];

  // ── postMessage listener analysis ──
  const PM_PATTERNS = {
    listener:   /addEventListener\s*\(\s*['"`]message['"`]/g,
    noOrigin:   /addEventListener\s*\(\s*['"`]message['"`]\s*,\s*(?:function\s*\([^)]*\)|(?:\([^)]*\)|\w+)\s*=>)\s*\{(?:(?!\.origin).)*?\}/gs,
    weakOrigin: /\.origin\.(indexOf|includes|endsWith|startsWith|match)\s*\(/g,
    evalSink:   /\.data[\s\S]{0,150}eval\s*\(/g,
    htmlSink:   /\.data[\s\S]{0,150}\.innerHTML\s*[=+]/g,
    locSink:    /\.data[\s\S]{0,150}location\.(href|assign|replace)/g,
    srcSink:    /\.data[\s\S]{0,150}\.src\s*=/g,
    srcdocSink: /\.data[\s\S]{0,150}\.srcdoc\s*=/g,
    wildcard:   /postMessage\s*\([^,]+,\s*['"`]\*['"`]\s*\)/g,
  };

  // ── Known vulnerable third-party script fingerprints ──
  // Detection by UNIQUE IDENTIFIER — no proximity window needed.
  // These patterns are confirmed vuln classes; the sink connection is known.
  const KNOWN_VULN_FINGERPRINTS = [
    { name: "StatCounter _heatmap injection", re: /\._heatmap\b/g, severity: "critical", ref: "?_heatmap= → regex bypass (unescaped dot) → attacker domain → createElement('script') loads attacker JS" },
    { name: "StatCounter hev path injection", re: /heatmap-embedded-.*?\+.*?\.js/g, severity: "high", ref: "?hev= param → path traversal in script src on statcounter.com" },
    { name: "Whisk widget-server override",   re: /whisk-widget-server/g, severity: "critical", ref: "widget-server param → script.src" },
    { name: "SaaSquatch _saasquatchExtra",    re: /_saasquatchExtra/g, severity: "high", ref: "base64 param → API endpoint → template → document.write" },
    { name: "Ketch endpoint override",        re: /ketch(cdn)?[\s\S]{0,100}(endpoint|server|api)/gi, severity: "high", ref: "consent widget endpoint override" },
    { name: "Staffbase SSOUrl sink",          re: /SSOUrl/g, severity: "critical", ref: "SSOUrl param → javascript: URI → XSS" },
    { name: "ScriptBlocker force_consent",    re: /force_consent[\s\S]{0,50}return/g, severity: "high", ref: "force_consent causes early return, skips DOM hooks" },
    { name: "DOMPurify CUSTOM_ELEMENT",       re: /CUSTOM_ELEMENT_HANDLING/g, severity: "medium", ref: "custom element handling can bypass sanitization" },
    { name: "Tealium qp. decoded params",     re: /utag\.data\[['"]qp\./gi, severity: "high", ref: "Tealium qp.* decoded URL params — check sinks" },
    { name: "IQD iqdeployment S3 traversal",  re: /iqdeployment/gi, severity: "critical", ref: "location.href → split('iqdeployment=') → S3 path concat → script injection (hash included)" },
    { name: "IQD iqd_mode S3 loader",         re: /iqd_mode/gi, severity: "critical", ref: "iqd_mode from URL → S3 bucket path concat → script load" },
    { name: "IQSLoader function",             re: /IQSLoader\s*\(/g, severity: "high", ref: "IQD dynamic script loader — check if URL is user-controlled" },
  ];

  // ── Supply-chain / S3 path patterns ──
  const SUPPLY_CHAIN = [
    { name: "S3 bucket path concat",   re: /(s3\.amazonaws\.com|s3-[\w-]+\.amazonaws\.com|s3\.[\w-]+\.amazonaws\.com)[\s\S]{0,100}\+/g },
    { name: "Azure blob path concat",  re: /blob\.core\.windows\.net[\s\S]{0,100}\+/g },
    { name: "GCS path concat",         re: /storage\.googleapis\.com[\s\S]{0,100}\+/g },
    { name: "CDN path from URL param", re: /(cdn|assets?|static|resources?)\s*[\+:]\s*(param|query|search|get)/gi },
  ];

  const DYNAMIC_LOAD_PATTERNS = [
    { name: "URL param → dynamic script load", re: /(location\.(href|search|hash)|document\.URL)[\s\S]{0,200}(createElement\s*\(\s*['"`]script|\.src\s*=[\s\S]{0,50}(https?:|\/\/))/gi, severity: "critical" },
    { name: "split() URL extraction → script",  re: /\.split\s*\(\s*['"`][^'"`]*=['"`]\s*\)[\s\S]{0,200}(\.src\s*=|createElement|IQSLoader|loadScript|appendScript)/gi, severity: "critical" },
    { name: "URL param → external URL concat",  re: /(getParam|searchParams|split\s*\(\s*['"`][\w]+=)[\s\S]{0,200}(s3[\w.-]*amazonaws|blob\.core\.windows|storage\.googleapis|cloudfront\.net)/gi, severity: "critical" },
    { name: "indexOf URL param → path build",   re: /indexOf\s*\(\s*['"`]\w+=.*?\)[\s\S]{0,200}(\.src|createElement|loadScript|\.open)/gi, severity: "high" },
  ];

  // ── Flow verification: checks if a matched flow has real data coupling ──
  function verifyFlow(code, matchStart, matchEnd) {
    const snippet = code.substring(matchStart, matchEnd);

    // Strong signal: param extraction via split/indexOf/substring between source and sink
    if (/split\s*\(/.test(snippet)) return "verified";
    if (/indexOf\s*\(/.test(snippet)) return "verified";
    if (/substring\s*\(/.test(snippet)) return "verified";
    if (/slice\s*\(/.test(snippet)) return "verified";
    if (/\.get\s*\(/.test(snippet)) return "verified";
    if (/getParam/.test(snippet)) return "verified";
    if (/searchParams/.test(snippet)) return "verified";
    if (/decodeURI/.test(snippet)) return "verified";

    // Strong signal: string concat building a URL
    if (/\+\s*['"`]?(https?:|\/\/)/.test(snippet)) return "verified";
    if (/\+\s*\w+\s*\+/.test(snippet) && /\.src|createElement|\.open/.test(snippet)) return "verified";

    // Weak signal: hardcoded URL assignment to .src → false positive
    if (/\.src\s*=\s*['"`]https?:\/\//.test(snippet)) return "false_positive";

    // Weak signal: .src used for Image() tracking pixel
    if (/new\s+Image/.test(snippet) && /\.src\s*=/.test(snippet)) return "false_positive";

    // Weak signal: gtag/analytics context
    if (/gtag|analytics|track|beacon|pixel|log/.test(snippet)) return "likely_fp";

    return "unverified";
  }

  function getLineNumber(code, index) {
    return code.substring(0, index).split("\n").length;
  }

  function getContext(code, index, radius) {
    radius = radius || 80;
    const start = Math.max(0, index - radius);
    const end = Math.min(code.length, index + radius);
    return code.substring(start, end).replace(/\s+/g, " ").trim();
  }

  function scanCode(code, scriptUrl) {
    const results = {
      sinks: [],
      sources: [],
      flows: [],
      postMessage: [],
      widgetOverrides: [],
      knownVuln: [],
      supplyChain: [],
    };

    const host = (() => {
      try { return new URL(scriptUrl).hostname; } catch { return scriptUrl; }
    })();

    const adTech = isAdTech(host);

    // Sinks
    for (const s of SINKS) {
      const re = new RegExp(s.re.source, "g" + (s.re.flags.includes("i") ? "i" : ""));
      let m;
      while ((m = re.exec(code)) !== null) {
        results.sinks.push({
          type: s.id,
          severity: s.severity,
          line: getLineNumber(code, m.index),
          context: getContext(code, m.index),
          script: host,
          url: scriptUrl,
          adTech,
        });
      }
    }

    // Sources
    for (const s of SOURCES) {
      const re = new RegExp(s.re.source, "g");
      let m;
      while ((m = re.exec(code)) !== null) {
        results.sources.push({
          type: s.id,
          line: getLineNumber(code, m.index),
          context: getContext(code, m.index),
          script: host,
          url: scriptUrl,
          adTech,
        });
      }
    }

    // Source→Sink flows — run verification pass
    for (const f of FLOW_PATTERNS) {
      const re = new RegExp(f.re.source, f.re.flags);
      let m;
      while ((m = re.exec(code)) !== null) {
        const verdict = verifyFlow(code, m.index, m.index + m[0].length);

        if (verdict === "false_positive") continue;

        let severity = "critical";
        if (verdict === "likely_fp") severity = "info";
        else if (verdict === "unverified") severity = "medium";

        results.flows.push({
          name: f.name,
          line: getLineNumber(code, m.index),
          context: getContext(code, m.index, 150),
          script: host,
          url: scriptUrl,
          severity,
          verified: verdict === "verified",
          adTech,
        });
      }
    }

    // postMessage analysis — always run (ad scripts can have real postMessage vulns)
    const listenerMatches = code.match(PM_PATTERNS.listener);
    if (listenerMatches) {
      const pmResult = {
        script: host,
        url: scriptUrl,
        listenerCount: listenerMatches.length,
        issues: [],
      };

      const noOrigin = code.match(PM_PATTERNS.noOrigin);
      if (noOrigin) {
        pmResult.issues.push({
          type: "NO_ORIGIN_CHECK",
          severity: "critical",
          count: noOrigin.length,
          context: noOrigin[0] ? noOrigin[0].substring(0, 200) : "",
        });
      }

      const weakOrigin = code.match(PM_PATTERNS.weakOrigin);
      if (weakOrigin) {
        pmResult.issues.push({
          type: "WEAK_ORIGIN_CHECK",
          severity: "high",
          detail: "Uses indexOf/includes/endsWith/startsWith — bypassable with attacker.trusted.com",
          count: weakOrigin.length,
        });
      }

      for (const [key, re] of Object.entries(PM_PATTERNS)) {
        if (["listener", "noOrigin", "weakOrigin"].includes(key)) continue;
        const sinkMatch = code.match(re);
        if (sinkMatch) {
          pmResult.issues.push({
            type: key.toUpperCase(),
            severity: key === "wildcard" ? "info" : "high",
            count: sinkMatch.length,
            context: sinkMatch[0] ? sinkMatch[0].substring(0, 150) : "",
          });
        }
      }

      if (pmResult.issues.length > 0) {
        results.postMessage.push(pmResult);
      }
    }

    // Widget endpoint override params — always run
    const paramReaders = [
      ...code.matchAll(/(?:get(?:Query)?Param(?:eter)?s?|URLSearchParams[\s\S]{0,50}\.get)\s*\(\s*['"`]([^'"`]+)['"`]/gi),
      ...code.matchAll(/(?:searchParams|params|query)\.(?:get|has)\s*\(\s*['"`]([^'"`]+)['"`]/gi),
      ...code.matchAll(/(?:search|location|href)[\s\S]{0,30}['"`]([a-zA-Z_-]{3,})['"` ]/g),
    ];

    for (const m of paramReaders) {
      const paramName = m[1];
      for (const wr of WIDGET_OVERRIDE_PARAMS) {
        if (wr.test(paramName)) {
          const afterIndex = m.index + m[0].length;
          const downstream = code.substring(afterIndex, afterIndex + 500);
          const hasSink = /\.src\s*=|createElement\s*\(\s*['"`]script|location\.(href|assign|replace)|window\.open|innerHTML|document\.write|fetch\s*\(|\.open\s*\(/.test(downstream);

          results.widgetOverrides.push({
            param: paramName,
            script: host,
            url: scriptUrl,
            line: getLineNumber(code, m.index),
            context: getContext(code, m.index, 120),
            reachesSink: hasSink,
            severity: hasSink ? "critical" : "medium",
          });
          break;
        }
      }
    }

    // Known vulnerable fingerprints — always run
    for (const fp of KNOWN_VULN_FINGERPRINTS) {
      const re = new RegExp(fp.re.source, fp.re.flags);
      let m;
      while ((m = re.exec(code)) !== null) {
        results.knownVuln.push({
          name: fp.name,
          ref: fp.ref,
          line: getLineNumber(code, m.index),
          context: getContext(code, m.index, 120),
          script: host,
          url: scriptUrl,
          severity: fp.severity || "high",
        });
      }
    }

    // Supply-chain patterns — always run
    for (const sc of SUPPLY_CHAIN) {
      const re = new RegExp(sc.re.source, sc.re.flags);
      let m;
      while ((m = re.exec(code)) !== null) {
        results.supplyChain.push({
          name: sc.name,
          line: getLineNumber(code, m.index),
          context: getContext(code, m.index),
          script: host,
          url: scriptUrl,
          severity: "high",
        });
      }
    }

    // Dynamic load patterns (URL input → external script loading)
    for (const dl of DYNAMIC_LOAD_PATTERNS) {
      const re = new RegExp(dl.re.source, dl.re.flags);
      let m;
      while ((m = re.exec(code)) !== null) {
        const verdict = verifyFlow(code, m.index, m.index + m[0].length);
        if (verdict === "false_positive") continue;

        results.supplyChain.push({
          name: dl.name,
          line: getLineNumber(code, m.index),
          context: getContext(code, m.index, 150),
          script: host,
          url: scriptUrl,
          severity: verdict === "verified" ? "critical" : "medium",
          verified: verdict === "verified",
          adTech,
        });
      }
    }

    return results;
  }

  return { scanCode, isAdTech, SINKS, SOURCES, FLOW_PATTERNS };
})();

if (typeof module !== "undefined") module.exports = Scanner;
