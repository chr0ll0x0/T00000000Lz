const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);

let scanResults = null;
let pageInfo = null;

// ── Tab switching ──
$$(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    $$(".tab").forEach(t => t.classList.remove("active"));
    $$(".panel").forEach(p => p.classList.remove("active"));
    tab.classList.add("active");
    $(`#panel-${tab.dataset.panel}`).classList.add("active");
  });
});

// ── Status helpers ──
function setStatus(text, state) {
  $("#statusText").textContent = text;
  const dot = $("#statusDot");
  dot.className = "dot";
  if (state) dot.classList.add(state);
}

function setProgress(pct) {
  const wrap = $("#progressWrap");
  const bar = $("#progressBar");
  if (pct < 0) { wrap.style.display = "none"; return; }
  wrap.style.display = "block";
  bar.style.width = pct + "%";
}

// ── Render helpers ──
function esc(s) {
  const d = document.createElement("div");
  d.textContent = s;
  return d.innerHTML;
}

function renderFinding(f) {
  const verifiedBadge = f.verified ? '<span class="badge-verified">VERIFIED</span>' : "";
  const adBadge = f.adTech ? '<span class="badge-adtech">AD-TECH</span>' : "";
  return `<div class="finding ${f.verified ? "finding-verified" : ""} ${f.adTech ? "finding-adtech" : ""}">
    <div class="title">
      <span class="severity ${f.severity || "info"}">${esc(f.severity || "info")}</span>
      ${verifiedBadge}${adBadge}
      <span class="name">${esc(f.name || f.type || "")}</span>
      ${f.line ? `<span class="line">L${f.line}</span>` : ""}
    </div>
    <div class="script">${esc(f.script || "")} ${f.url ? "— " + esc(truncUrl(f.url)) : ""}</div>
    ${f.detail ? `<div class="script">${esc(f.detail)}</div>` : ""}
    ${f.context ? `<div class="ctx">${esc(f.context)}</div>` : ""}
    ${f.ref ? `<div class="script">${esc(f.ref)}</div>` : ""}
  </div>`;
}

function truncUrl(url) {
  try {
    const u = new URL(url);
    const path = u.pathname + u.search;
    return u.hostname + (path.length > 60 ? path.substring(0, 57) + "..." : path);
  } catch { return url; }
}

// ── Main scan ──
$("#btnScan").addEventListener("click", async () => {
  $("#btnScan").disabled = true;
  setStatus("Enumerating page scripts...", "scanning");
  setProgress(5);

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) { setStatus("No active tab", "error"); return; }

  try {
    pageInfo = await chrome.tabs.sendMessage(tab.id, { action: "enumerate" });
  } catch {
    setStatus("Cannot access page — try reloading", "error");
    $("#btnScan").disabled = false;
    setProgress(-1);
    return;
  }

  const thirdParty = pageInfo.scripts.thirdParty;
  setStatus(`Found ${thirdParty.length} third-party scripts — downloading...`, "scanning");
  setProgress(10);

  const allResults = {
    sinks: [], sources: [], flows: [], postMessage: [],
    widgetOverrides: [], knownVuln: [], supplyChain: [],
  };

  for (let i = 0; i < thirdParty.length; i++) {
    const url = thirdParty[i];
    const pct = 10 + Math.round((i / thirdParty.length) * 80);
    setProgress(pct);
    setStatus(`Scanning ${i + 1}/${thirdParty.length}: ${truncUrl(url)}`, "scanning");

    try {
      const resp = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ action: "fetchScript", url }, r => {
          if (r && r.ok) resolve(r);
          else reject(r ? r.error : "fetch failed");
        });
      });

      const code = resp.code;
      if (!code || code.length < 20) continue;

      const r = Scanner.scanCode(code, url);
      for (const key of Object.keys(allResults)) {
        if (r[key]) allResults[key].push(...r[key]);
      }
    } catch {}
  }

  // Scan inline scripts — full scan for supply-chain, known vulns, flows, postMessage
  try {
    const inlineResp = await chrome.tabs.sendMessage(tab.id, { action: "getInlineScripts" });
    if (inlineResp && inlineResp.scripts) {
      for (let idx = 0; idx < inlineResp.scripts.length; idx++) {
        const code = inlineResp.scripts[idx];
        const label = pageInfo.url + ` [inline#${idx}]`;
        const r = Scanner.scanCode(code, label);
        for (const key of Object.keys(allResults)) {
          if (r[key]) allResults[key].push(...r[key]);
        }
      }
    }
  } catch {}

  setProgress(95);
  scanResults = allResults;
  renderResults();
  setProgress(-1);

  const total = allResults.flows.length + allResults.postMessage.reduce((a, p) => a + p.issues.length, 0) +
    allResults.widgetOverrides.length + allResults.knownVuln.length + allResults.supplyChain.length;

  if (total > 0) {
    setStatus(`Scan complete — ${total} finding(s) across ${thirdParty.length} scripts`, "done");
  } else {
    setStatus(`Clean — no findings in ${thirdParty.length} third-party scripts`, "done");
  }

  $("#btnScan").disabled = false;
});

function renderResults() {
  const r = scanResults;

  // Summary counts — only count verified or non-ad-tech as critical
  let crit = 0, high = 0, med = 0;
  const countSev = arr => arr.forEach(f => {
    const sev = f.severity;
    if (sev === "critical") crit++;
    else if (sev === "high") high++;
    else if (sev === "medium") med++;
  });

  countSev(r.flows);
  countSev(r.widgetOverrides);
  countSev(r.knownVuln);
  countSev(r.supplyChain);
  r.postMessage.forEach(p => p.issues.forEach(i => {
    if (i.severity === "critical") crit++;
    else if (i.severity === "high") high++;
  }));

  $("#critCount").textContent = crit;
  $("#highCount").textContent = high;
  $("#medCount").textContent = med;
  $("#infoCount").textContent = pageInfo.scripts.thirdParty.length;
  $("#summary").style.display = "grid";
  $("#tabBar").style.display = "flex";

  // Badges
  $("#flowsBadge").textContent = r.flows.length;
  $("#postmsgBadge").textContent = r.postMessage.length;
  $("#widgetsBadge").textContent = r.widgetOverrides.length;
  $("#sinksBadge").textContent = r.sinks.length;
  $("#knownBadge").textContent = r.knownVuln.length + r.supplyChain.length;
  $("#scriptsBadge").textContent = pageInfo.scripts.thirdParty.length;

  // ── Flows panel — verified first, then by severity ──
  const flowsPanel = $("#panel-flows");
  if (r.flows.length === 0) {
    flowsPanel.innerHTML = '<div class="empty-state">No source-to-sink flows detected</div>';
  } else {
    const sevOrder = { critical: 0, high: 1, medium: 2, info: 3 };
    const sorted = [...r.flows].sort((a, b) => {
      if (a.verified && !b.verified) return -1;
      if (!a.verified && b.verified) return 1;
      return (sevOrder[a.severity] || 9) - (sevOrder[b.severity] || 9);
    });
    const verified = sorted.filter(f => f.verified);
    const unverified = sorted.filter(f => !f.verified);
    let html = "";
    if (verified.length > 0) {
      html += `<div class="section-label" style="color:var(--red)">Verified Flows (${verified.length})</div>`;
      html += verified.map(f => renderFinding(f)).join("");
    }
    if (unverified.length > 0) {
      html += `<div class="section-label">Needs Review (${unverified.length})</div>`;
      html += unverified.map(f => renderFinding(f)).join("");
    }
    flowsPanel.innerHTML = html;
  }

  // ── postMessage panel ──
  const pmPanel = $("#panel-postmsg");
  if (r.postMessage.length === 0) {
    pmPanel.innerHTML = '<div class="empty-state">No postMessage listener issues in third-party scripts</div>';
  } else {
    let html = '<div class="section-label">postMessage Listeners</div>';
    for (const pm of r.postMessage) {
      html += `<div class="finding">
        <div class="title">
          <span class="name">${esc(pm.script)}</span>
          <span class="line">${pm.listenerCount} listener(s)</span>
        </div>
        <div class="script">${esc(truncUrl(pm.url))}</div>`;
      for (const issue of pm.issues) {
        html += `<div style="margin-top:4px">
          <span class="severity ${issue.severity}">${esc(issue.severity)}</span>
          <strong>${esc(issue.type)}</strong>
          ${issue.detail ? ` — ${esc(issue.detail)}` : ""}
          ${issue.count ? ` (${issue.count}x)` : ""}
        </div>`;
        if (issue.context) html += `<div class="ctx">${esc(issue.context)}</div>`;
      }
      html += "</div>";
    }
    pmPanel.innerHTML = html;
  }

  // ── Widgets panel ──
  const widgetPanel = $("#panel-widgets");
  if (r.widgetOverrides.length === 0) {
    widgetPanel.innerHTML = '<div class="empty-state">No widget endpoint override params detected</div>';
  } else {
    widgetPanel.innerHTML = '<div class="section-label">Widget Endpoint Override Params</div>' +
      r.widgetOverrides.map(w => renderFinding({
        ...w,
        name: `?${w.param}=`,
        type: w.param,
        detail: w.reachesSink ? "Param value reaches a dangerous sink downstream" : "Override param found — trace manually",
      })).join("");
  }

  // ── Sinks panel ──
  const sinksPanel = $("#panel-sinks");
  if (r.sinks.length === 0) {
    sinksPanel.innerHTML = '<div class="empty-state">No sinks found in third-party scripts</div>';
  } else {
    const grouped = {};
    r.sinks.forEach(s => {
      if (!grouped[s.type]) grouped[s.type] = [];
      grouped[s.type].push(s);
    });
    let html = "";
    for (const [type, items] of Object.entries(grouped)) {
      html += `<div class="section-label">${esc(type)} (${items.length})</div>`;
      html += items.slice(0, 10).map(s => renderFinding(s)).join("");
      if (items.length > 10) html += `<div class="script">...and ${items.length - 10} more</div>`;
    }
    sinksPanel.innerHTML = html;
  }

  // ── Known vulns panel — verified supply chain first ──
  const knownPanel = $("#panel-known");
  const combined = [...r.knownVuln, ...r.supplyChain];
  if (combined.length === 0) {
    knownPanel.innerHTML = '<div class="empty-state">No known vulnerable patterns or supply-chain issues</div>';
  } else {
    const verifiedSC = combined.filter(k => k.verified);
    const knownFingerprints = combined.filter(k => !k.verified && k.ref);
    const otherSC = combined.filter(k => !k.verified && !k.ref);
    let html = "";
    if (verifiedSC.length > 0) {
      html += `<div class="section-label" style="color:var(--red)">Verified Supply Chain (${verifiedSC.length})</div>`;
      html += verifiedSC.map(k => renderFinding(k)).join("");
    }
    if (knownFingerprints.length > 0) {
      html += `<div class="section-label">Known Fingerprints (${knownFingerprints.length})</div>`;
      html += knownFingerprints.map(k => renderFinding(k)).join("");
    }
    if (otherSC.length > 0) {
      html += `<div class="section-label">Supply Chain Patterns (${otherSC.length})</div>`;
      html += otherSC.map(k => renderFinding(k)).join("");
    }
    knownPanel.innerHTML = html;
  }

  // ── Scripts panel ──
  const scriptsPanel = $("#panel-scripts");
  let shtml = "";

  if (pageInfo.stack.length > 0) {
    shtml += '<div class="section-label">Tech Stack</div><div class="tech-chips">';
    pageInfo.stack.forEach(t => {
      const warn = /jquery\s*[123]\.[0-9]/i.test(t) || /angularjs/i.test(t);
      shtml += `<span class="chip ${warn ? "warn" : ""}">${esc(t)}</span>`;
    });
    shtml += "</div>";
  }

  if (pageInfo.headers.csp) {
    shtml += `<div class="section-label">CSP (meta)</div><div class="ctx">${esc(pageInfo.headers.csp)}</div>`;
  } else {
    shtml += '<div class="section-label">CSP</div><div class="script">No meta CSP detected (check response headers)</div>';
  }

  shtml += `<div class="section-label">Third-Party Scripts (${pageInfo.scripts.thirdParty.length})</div><div class="script-list">`;
  for (const url of pageInfo.scripts.thirdParty) {
    try {
      const u = new URL(url);
      shtml += `<div class="script-item">
        <span class="host">${esc(u.hostname)}</span>
        <span class="path">${esc(u.pathname.split("/").pop() || u.pathname)}</span>
      </div>`;
    } catch {
      shtml += `<div class="script-item"><span class="host">${esc(url)}</span></div>`;
    }
  }
  shtml += "</div>";

  shtml += `<div class="section-label">First-Party Scripts (${pageInfo.scripts.firstParty.length})</div>`;
  shtml += `<div class="script" style="color:var(--green)">Inline scripts fully scanned for supply-chain, flows, postMessage, and known vulns</div>`;
  shtml += `<div class="script" style="color:var(--orange)">Use Deep Scan to find scripts hidden behind consent/ScriptBlocker</div>`;

  scriptsPanel.innerHTML = shtml;

  // ── Export panel ──
  renderExport();
}

function renderExport() {
  const panel = $("#panel-export");
  const r = scanResults;
  if (!r) { panel.innerHTML = '<div class="empty-state">Run a scan first</div>'; return; }

  const report = {
    scan_date: new Date().toISOString(),
    target: pageInfo.url,
    tech_stack: pageInfo.stack,
    csp: pageInfo.headers.csp,
    third_party_scripts: pageInfo.scripts.thirdParty.length,
    findings: {
      source_sink_flows: r.flows.map(f => ({
        pattern: f.name,
        script: f.script,
        line: f.line,
        context: f.context,
        severity: f.severity,
      })),
      postmessage_issues: r.postMessage.map(p => ({
        script: p.script,
        url: p.url,
        listeners: p.listenerCount,
        issues: p.issues.map(i => ({
          type: i.type,
          severity: i.severity,
          detail: i.detail,
          count: i.count,
        })),
      })),
      widget_overrides: r.widgetOverrides.map(w => ({
        param: w.param,
        script: w.script,
        line: w.line,
        reaches_sink: w.reachesSink,
        severity: w.severity,
        context: w.context,
      })),
      known_vulns: r.knownVuln.map(k => ({
        name: k.name,
        ref: k.ref,
        script: k.script,
        line: k.line,
        context: k.context,
      })),
      supply_chain: r.supplyChain.map(s => ({
        name: s.name,
        script: s.script,
        line: s.line,
        context: s.context,
      })),
    },
    sink_summary: (() => {
      const counts = {};
      r.sinks.forEach(s => counts[s.type] = (counts[s.type] || 0) + 1);
      return counts;
    })(),
    source_summary: (() => {
      const counts = {};
      r.sources.forEach(s => counts[s.type] = (counts[s.type] || 0) + 1);
      return counts;
    })(),
  };

  panel.innerHTML = `
    <div class="section-label">JSON Report</div>
    <textarea class="export-area" id="exportArea" readonly>${esc(JSON.stringify(report, null, 2))}</textarea>
    <div style="margin-top:6px;display:flex;gap:6px">
      <button id="btnCopy">Copy to Clipboard</button>
      <button id="btnDownload">Download JSON</button>
    </div>
  `;

  $("#btnCopy").addEventListener("click", () => {
    navigator.clipboard.writeText(JSON.stringify(report, null, 2));
    $("#btnCopy").textContent = "Copied";
    setTimeout(() => { $("#btnCopy").textContent = "Copy to Clipboard"; }, 1500);
  });

  $("#btnDownload").addEventListener("click", () => {
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    const host = new URL(pageInfo.url).hostname.replace(/\./g, "_");
    a.download = `3p-domxss-${host}-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  });
}

// ── Export button in controls ──
$("#btnExport").addEventListener("click", () => {
  if (!scanResults) return;
  $$(".tab").forEach(t => t.classList.remove("active"));
  $$(".panel").forEach(p => p.classList.remove("active"));
  $$(".tab").forEach(t => { if (t.dataset.panel === "export") t.classList.add("active"); });
  $("#panel-export").classList.add("active");
  renderExport();
});

// ── Deep Scan: bypass consent blockers and re-scan for hidden scripts ──
$("#btnDeep").addEventListener("click", async () => {
  if (!scanResults) { setStatus("Run a normal scan first", "error"); return; }
  $("#btnDeep").disabled = true;
  setStatus("Deep Scan — reloading with consent bypass...", "scanning");
  setProgress(10);

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) { setStatus("No active tab", "error"); return; }

  const bypassParams = ["me_force_consent=true"];
  let targetUrl;
  try {
    const u = new URL(pageInfo.url);
    for (const p of bypassParams) {
      const [k, v] = p.split("=");
      u.searchParams.set(k, v);
    }
    targetUrl = u.toString();
  } catch {
    setStatus("Invalid page URL", "error");
    $("#btnDeep").disabled = false;
    setProgress(-1);
    return;
  }

  await chrome.tabs.update(tab.id, { url: targetUrl });
  setStatus("Waiting for page to load with consent bypass...", "scanning");
  setProgress(30);

  await new Promise(resolve => {
    const listener = (tabId, info) => {
      if (tabId === tab.id && info.status === "complete") {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
    setTimeout(() => { chrome.tabs.onUpdated.removeListener(listener); resolve(); }, 10000);
  });

  await new Promise(r => setTimeout(r, 2000));
  setStatus("Deep scanning inline scripts after consent bypass...", "scanning");
  setProgress(60);

  const deepResults = {
    sinks: [], sources: [], flows: [], postMessage: [],
    widgetOverrides: [], knownVuln: [], supplyChain: [],
  };

  try {
    const inlineResp = await chrome.tabs.sendMessage(tab.id, { action: "getInlineScripts" });
    if (inlineResp && inlineResp.scripts) {
      setStatus(`Deep scanning ${inlineResp.scripts.length} inline scripts...`, "scanning");
      for (let idx = 0; idx < inlineResp.scripts.length; idx++) {
        const code = inlineResp.scripts[idx];
        const label = targetUrl + ` [deep-inline#${idx}]`;
        const r = Scanner.scanCode(code, label);
        for (const key of Object.keys(deepResults)) {
          if (r[key]) deepResults[key].push(...r[key]);
        }
      }
    }
  } catch {}

  setProgress(80);

  // Also re-scan any new external scripts that appeared after consent bypass
  try {
    const newPageInfo = await chrome.tabs.sendMessage(tab.id, { action: "enumerate" });
    if (newPageInfo && newPageInfo.scripts) {
      const existingUrls = new Set(pageInfo.scripts.thirdParty);
      const newScripts = newPageInfo.scripts.thirdParty.filter(u => !existingUrls.has(u));
      if (newScripts.length > 0) {
        setStatus(`Found ${newScripts.length} new scripts after consent bypass...`, "scanning");
        for (const url of newScripts) {
          try {
            const resp = await new Promise((resolve, reject) => {
              chrome.runtime.sendMessage({ action: "fetchScript", url }, r => {
                if (r && r.ok) resolve(r);
                else reject(r ? r.error : "fetch failed");
              });
            });
            if (resp.code && resp.code.length >= 20) {
              const r = Scanner.scanCode(resp.code, url);
              for (const key of Object.keys(deepResults)) {
                if (r[key]) deepResults[key].push(...r[key]);
              }
            }
          } catch {}
        }
      }
    }
  } catch {}

  // Merge deep results into main results (deduplicate by context)
  const existingCtx = new Set();
  for (const key of Object.keys(scanResults)) {
    const arr = scanResults[key];
    if (Array.isArray(arr)) {
      arr.forEach(f => { if (f.context) existingCtx.add(f.context); });
    }
  }

  let newFindings = 0;
  for (const key of Object.keys(deepResults)) {
    const arr = deepResults[key];
    if (!Array.isArray(arr)) continue;
    for (const f of arr) {
      if (f.context && existingCtx.has(f.context)) continue;
      scanResults[key].push(f);
      newFindings++;
    }
  }

  setProgress(95);
  renderResults();
  setProgress(-1);

  if (newFindings > 0) {
    setStatus(`Deep Scan complete — ${newFindings} NEW finding(s) from consent bypass`, "done");
  } else {
    setStatus("Deep Scan complete — no additional findings after consent bypass", "done");
  }

  $("#btnDeep").disabled = false;
});

// ── Clear button ──
$("#btnClear").addEventListener("click", () => {
  scanResults = null;
  pageInfo = null;
  setStatus("Ready — click Scan to analyze third-party scripts", "");
  $("#summary").style.display = "none";
  $("#tabBar").style.display = "none";
  $$(".panel").forEach(p => { p.innerHTML = ""; p.classList.remove("active"); });
  $("#panel-flows").classList.add("active");
  $$(".tab").forEach(t => t.classList.remove("active"));
  $$(".tab")[0].classList.add("active");
});
