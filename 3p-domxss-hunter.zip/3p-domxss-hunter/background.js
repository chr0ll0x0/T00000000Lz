chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "fetchScript") {
    fetch(msg.url)
      .then(r => r.text())
      .then(code => sendResponse({ ok: true, code }))
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
});
